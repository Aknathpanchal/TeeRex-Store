import React from 'react'

function Cart() {
  return (
    <div>
      hi
    </div>
  )
}

export default Cart
