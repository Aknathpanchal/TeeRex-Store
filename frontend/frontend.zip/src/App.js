import './App.css';
import { MainRoutes } from './Components/MainRoutes';
// import Product from './Pages/Product';

function App() {
  return (
    <div className="App">
      {/* <Product/> */}
      <MainRoutes/>
    </div>
  );
}

export default App;
